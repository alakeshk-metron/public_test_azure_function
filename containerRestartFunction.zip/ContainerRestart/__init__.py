import logging
import azure.functions as func
import os
import asyncio
from azure.identity import DefaultAzureCredential
from azure.mgmt.appcontainers import ContainerAppsAPIClient

app = func.FunctionApp()

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def restart_container_app_revision_async(
    client: ContainerAppsAPIClient,
    resource_group_name: str,
    container_app_name: str,
    revision_name: str
):
    logging.info(f"Restarting revision '{revision_name}' for container app '{container_app_name}'...")
    try:
        poller = client.container_apps_revisions.begin_restart_revision(
            resource_group_name=resource_group_name,
            container_app_name=container_app_name,
            revision_name=revision_name
        )
        poller.result()
        logging.info(f"Restart successful for revision '{revision_name}'.")
    except Exception as e:
        logging.error(f"Restart failed: {e}")
        raise

def main():
    logging.info('Timer trigger function executed.')

    subscription_id = os.getenv("SUBSCRIPTION_ID")
    resource_group_name = os.getenv("RESOURCE_GROUP_NAME")
    container_app_name = os.getenv("CONTAINER_APP_NAME")

    if not all([subscription_id, resource_group_name, container_app_name]):
        logging.error("Missing required environment variables.")
        return

    try:
        credential = DefaultAzureCredential()
        client = ContainerAppsAPIClient(credential, subscription_id)

        container_app = client.container_apps.get(resource_group_name, container_app_name)
        revision_name = container_app.latest_ready_revision_name

        if not revision_name:
            logging.error("No ready revision found. Cannot restart.")
            return

        restart_container_app_revision_async(client, resource_group_name, container_app_name, revision_name)

    except Exception as e:
        logging.error(f"An error occurred during the restart process: {e}")

@app.timer_trigger(schedule="0 0 12 * * 0", arg_name="myTimer", run_on_startup=False,
              use_monitor=False) 
def timer_trigger(myTimer: func.TimerRequest) -> None:
    if myTimer.past_due:
        logging.info('The timer is past due!')
    main()

    logging.info('Python timer trigger function executed.')