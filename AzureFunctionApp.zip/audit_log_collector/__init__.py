import logging
import azure.functions as func
import azure.durable_functions as df

import logging
import time

from ..SharedCode.azure_functions.audit_log_collector import bloodhound_audit_logs_collector_main_function

def main(myTimer: func.TimerRequest) -> None:
    if myTimer.past_due:
        logging.info('The timer is past due!')

    # initialize last_audit_logs_timestamp here instead of as parameter
    last_audit_logs_timestamp = {}

    print("Starting audit log collector function")

    bloodhound_audit_logs_collector_main_function(last_audit_logs_timestamp)

    logging.info(f"Value of last_audit_logs_timestamp at start: {last_audit_logs_timestamp}")

    logging.info('Python timer trigger function executed.')
